﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace JogoMemoria
{
    public partial class Form1 : Form
    {
        int movimentos, click, cartaEncontrada, numTag;
        Image [] turma = new Image[9];
        List<string> lista = new List<string>();

        int[] tags = new int[2];
        


        public Form1()
        {
            InitializeComponent();
            Start();
        }

        private void Start() { 
            foreach(PictureBox Item in Controls.OfType<PictureBox>()) {
                numTag = int.Parse(String.Format("{0}", Item.Tag));
                turma[numTag] = Item.Image;
                Item.Image = Properties.Resources.mm;
                Item.Enabled =true;
            }
            Aleatorio();
        }

        private void Aleatorio()
        {
            foreach (PictureBox Item in Controls.OfType<PictureBox>())
            { 
                Random ale = new Random();
                int[] xL = { 95, 249, 400, 542, 683, 831 };
                int[] yL = { 55, 259, 467 };
            Repete:
                var x = xL[ale.Next(0, xL.Length)];
                var y = yL[ale.Next(0, yL.Length)];

                Item.Location = new Point(x, y);

                String verificar = x.ToString() + y.ToString();

                if (lista.Contains(verificar))
                {
                    goto Repete;

                }
                else
                {
                    Item.Location = new Point(x, y);
                    lista.Add(verificar);
                }
            }

         }

        private void ImagensClick_Click(object sender, EventArgs e)
        {
            bool parEncontrado = false;

            PictureBox pic = (PictureBox)sender;
            click++;

            numTag = int.Parse(String.Format("{0}", pic.Tag));
            pic.Image = turma[numTag];
            pic.Refresh();

            if(click == 1)
            {
                tags[0] = int.Parse(String.Format("{0}", pic.Tag));
                
            }
            else if(click == 2)
            {
                movimentos++;
                lblMovimentos.Text = "Movimentos: " + movimentos.ToString();
                tags[1] = int.Parse(String.Format("{0}", pic.Tag));
                parEncontrado = ChecagemPares();
                Desvirar(parEncontrado);
            }
        }

        private bool ChecagemPares()
        {
            click = 0;
            if (tags[0] == tags[1]) {return true;} else {return false;}
        }

        private void Desvirar(bool check)
        {
            Thread.Sleep(500);

            foreach (PictureBox Item in Controls.OfType<PictureBox>()){

                if (int.Parse(String.Format("{0}", Item.Tag)) == tags[0] ||
                    int.Parse(String.Format("{0}", Item.Tag)) == tags[1])
                {
                    if(check == true)
                    {
                        cartaEncontrada++;
                        Item.Enabled = false;
                    }
                    else {
                        Item.Image = Properties.Resources.mm;
                        Item.Refresh(); 
                    }
                }

            }
            
            FinalJogo();
        }
        private void FinalJogo()
        {
            if(cartaEncontrada == (turma.Length *2))
            {
                MessageBox.Show("Parabens vc terminou o jogo com: " + movimentos.ToString() + "movimentos");
                DialogResult msg = MessageBox.Show("Deseja continuar o jogo", "Caixa de Pergunta", MessageBoxButtons.YesNo);
                
                if (msg == DialogResult.Yes)
                {
                    click = 0; movimentos = 0; cartaEncontrada = 0;
                    lista.Clear();
                    Start();

                }
                else if (msg == DialogResult.No)
                {
                    MessageBox.Show("Obrigado por jogar");
                    Application.Exit();
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void Movimentos_Click(object sender, EventArgs e)
        {

        }
    }
}
